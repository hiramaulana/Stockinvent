	<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "db_ujikom";
	
$con = mysqli_connect($host, $user, $pass, $db) or die('KONEKSI GAGAL');
?>

