<?php

$username = "root";
$password = "";
$database = "db_ujikom";
$hostname = "localhost";
$con = mysqli_connect($hostname,$username,$password,$database) or die("Connection Corrupt");


class oop{
    public function login($con, $username, $password){
        $sql = "SELECT * FROM tb_petugas WHERE username ='$username' and password='$password'";
        $query = mysqli_query($con,$sql);
        $rows  = mysqli_num_rows($query);
        $data = mysqli_fetch_array($query);
        if($rows > 0){
                if($data['id_level'] == '1'){
                    setcookie("id_petugas", $data['id_petugas'], time()+(86400*30), "/");
                    echo "<script>alert('Login Berhasil Administrator');document.location.href='../app/admin'</script>"; 
                }else{
                    setcookie("id_petugas", $data['id_petugas'], time()+(86400*30), "/");
                    echo "<script>alert('Login Berhasil Petugas');document.location.href='../app/operator'</script>";
                }
        }else{
            echo "<script>alert('Username Atau Password Yang Anda Masukan Salah')</script>";
        }
    }

    public function logout(){
        @session_destroy();
        setcookie("id_petugas", "",time()-1,"/");
        echo "<script>alert('Logout Berhasil! Semoga Harimu Menyenangkan Petugas');document.location.href='../../login/index.php'</script>";
    }

    public function login1($con, $nip, $password){
        $sql = "SELECT * FROM tb_pegawai WHERE nip ='$nip' and password='$password'";
        $query = mysqli_query($con,$sql);
        $rows  = mysqli_num_rows($query);
        $data = mysqli_fetch_array($query);
        if($rows > 0){
            setcookie("id_pegawai", $data['id_pegawai'], time()+(86400*30), "/");
            echo "<script>alert('Login Berhasil');document.location.href='../app/pegawai'</script>"; 
        }else{
            echo "<script>alert('NIP Atau Password Yang Anda Masukan Salah')</script>";
        }
    }

    public function logout1(){
        @session_destroy();
        setcookie("id_pegawai", "",time()-1,"/");
        echo "<script>alert('Logout Berhasil! Semoga Harimu Menyenangkan');document.location.href='../../login/pegawai.php'</script>";
    }

    public function tampilbarang($con){
        $sql = "SELECT tb_inventaris.*, tb_ruang.nama_ruang from tb_inventaris 
                inner join tb_ruang 
                on 
                tb_ruang.id_ruang = tb_inventaris.id_ruang";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampilbarang1($con){
        $sql = "SELECT tb_inventaris.*, tb_ruang.nama_ruang from tb_inventaris 
                inner join tb_ruang 
                on 
                tb_ruang.id_ruang = tb_inventaris.id_ruang
                WHERE tb_inventaris.status = '3'";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampilmaintenance($con){
        $sql = "SELECT tb_maintenance.*, tb_inventaris.*, tb_peminjaman.*, tb_pegawai.* from tb_inventaris 
                join tb_maintenance
                on
                tb_maintenance.id_inventaris = tb_inventaris.id_inventaris
                join tb_peminjaman 
                on 
                tb_peminjaman.id_peminjaman = tb_maintenance.id_peminjaman
                join tb_pegawai
                on
                tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai
                where tb_maintenance.id_maintenance = '$_GET[id]'";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampilsupply($con){
        $sql = "SELECT tb_inventaris.nama, tb_supply.* from tb_inventaris 
                inner join tb_supply 
                on 
                tb_supply.id_inventaris = tb_inventaris.id_inventaris";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampilpeminjaman($con){
        $sql = "SELECT tb_inventaris.*, tb_peminjaman.*, tb_pegawai.* from tb_inventaris 
                        join tb_peminjaman 
                        on 
                        tb_peminjaman.id_inventaris = tb_inventaris.id_inventaris
                        join tb_pegawai
                        on
                        tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampilpengembalian($con){
        $sql = "SELECT tb_inventaris.*, tb_peminjaman.*, tb_pegawai.*, tb_detail_pinjam.* from tb_inventaris 
                join tb_peminjaman 
                on 
                tb_peminjaman.id_inventaris = tb_inventaris.id_inventaris
                join tb_pegawai
                on
                tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai
                join tb_detail_pinjam
                on
                tb_peminjaman.id_peminjaman = tb_detail_pinjam.id_peminjaman 
                where 
                tb_peminjaman.id_peminjaman = tb_detail_pinjam.id_peminjaman";
        $query = mysqli_query($con, $sql);
        while($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampil($con, $table){
        $sql = "SELECT * FROM $table";
        $query = mysqli_query($con, $sql);
        while ($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    public function tampil1($con, $table, $where){
        $sql = "SELECT * FROM $table WHERE $where";
        $query = mysqli_query($con, $sql);
        while ($data = mysqli_fetch_array($query))
            @$isi[] = $data;
        return @$isi;
    }

    function simpan($con, $table, $isi, $alert, $form){
        $sql = "INSERT INTO $table SET $isi";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
                    alert('$alert');
                    document.location.href='$form'
                  </script>";
        }else{
            echo "<script>
                    alert('Gagal Melakukan Aktivitas');
                    document.location.href='$form'
                  </script>";
        }
    }

    function edit($con, $table, $where){
        $sql = "SELECT * FROM $table WHERE $where";
        $query = mysqli_query($con, $sql);
        while ($data = mysqli_fetch_array($query))
            $isi[] = $data;
        return $isi;
    }

    function update($con, $table, $isi, $where, $form){
        $sql = "UPDATE $table SET $isi WHERE $where";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
                    alert('Success');
                    document.location.href='$form'
                  </script>";
        }else{
            echo "<script>
                    alert('Failed');
                    document.location.href='$form'
                  </script>";
        }
    }

    function hapus($con, $table, $where, $form){
        $sql = "DELETE FROM $table WHERE $where";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>
                    alert('Berhasil Menghapus');
                    document.location.href='$form'
                  </script>";
        }else{
            echo "<script>
                    alert('Failed');
                    document.location.href='$form'
                  </script>";
        }
    }



}

?>