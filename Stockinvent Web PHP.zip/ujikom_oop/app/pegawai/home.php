<div class="container">
<div class="row">
	<div class="col-sm-12">
		<div class="tile text-center">
			<h1 align="center">Inventarisasi Sarana dan Prasarana</h1>
			<hr>
			<video style="width: 90%; height: 90%" controls autoplay><source src="mari.mp4" type="video/mp4"></video>
			<audio controls><source src="mari.mp3" type="audio/mp3"></audio>
		</div>
	</div>
</div>
</div>
<div class="row">
	
</div>
