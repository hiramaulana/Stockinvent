<?php 

@$id = $_GET[id];
if (isset($_GET['pinjam'])) {
	$disabled = 'disabled';

	$table = "tb_inventaris";
	$where = "id_inventaris = '$id'";
	$tampilbarang = $perintah->tampil1($con, $table, $where);
	foreach ($tampilbarang as $data) {}
		$idruang = $data['id_ruang'];
		$idjenis = $data['id_jenis'];

	$table1 = "tb_ruang";
	$where1 = "id_ruang = '$idruang'";
	$tampilruang = $perintah->tampil1($con, $table1, $where1);
	foreach ($tampilruang as $data1) {}
		$ruang = $data1['nama_ruang'];
	
	$table2 = "tb_jenis";
	$where2 = "id_jenis = '$idjenis'";
	$tampiljenis = $perintah->tampil1($con, $table2, $where2);
	foreach ($tampiljenis as $data2) {}
		$jenis = $data2['nama_jenis'];

}

if (isset($_POST['simpan'])) {
	@$barang = $data['id_inventaris'];
	@$jumlah = $_POST['jumlah'];
	@$tgl_pinjam = $_POST['tgl_pinjam'];
	@$tgl_kembali = $_POST['tgl_kembali'];
	@$id_peminjaman = $kode_acak;
	@$form = "?page=peminjaman";
	@$alert = "Data Peminjaman Berhasil Diinput";
	if ($cookies != '') {
		$table = "tb_peminjaman";
		$isi = "id_peminjaman = '$id_peminjaman', id_inventaris = '$barang', jumlah = '$jumlah', tgl_pinjam = '$tgl_pinjam', tgl_kembali = '$tgl_kembali', tgl_kembali1 = '', status_pinjam = '1', id_pegawai = '$cookies'";
		$input_peminjaman = $perintah->simpan($con, $table, $isi, $alert, $form);
		$table1 = "tb_detail_pinjam";
		$isi1 = "id_detail_pinjam = '', id_inventaris = '$barang', id_peminjaman = '$id_peminjaman', jumlah = '$jumlah'";
		$input_detail_pinjam = $perintah->simpan($con, $table1, $isi1, $alert, $form);
	}else{
		echo "<script>alert('Ilegal Activity, Anda Tidak Dikenal Dalam Sistem Ini Silahkan Logout dan Login Kembali');document.location.href='?page=inventarisir'</script>";
	}
	
}

 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Peminjaman Anda</h3>
		<hr>
		<table class="table table-bordered" id="example1">
			<style type="text/css">
				.hide{
					display: none;
				}
			</style>
			<thead>
				<tr>
					<th>No</th>
					<th class="hide">NIP</th>
					<th>Nama Barang</th>
					<th>Jumlah</th>
					<th>Tanggal Peminjaman</th>
					<th>Tanggal Rencana Pengembalian</th>
					<th>Tanggal Pengembalian</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					
					$sql3 = mysqli_query($con, "SELECT tb_inventaris.*, tb_peminjaman.*, tb_pegawai.* from tb_inventaris 
						join tb_peminjaman 
						on 
						tb_peminjaman.id_inventaris = tb_inventaris.id_inventaris
						join tb_pegawai
						on
						tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai
						where
						tb_pegawai.id_pegawai = '$cookies'");
					while ($data3 = mysqli_fetch_array($sql3)) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td class="hide"><?php echo $data3['nip'] ?></td>
					<td><?php echo $data3['nama'] ?></td>
					<td><?php echo $data3['jumlah'] ?></td>
					<td><?php echo $data3['tgl_pinjam'] ?></td>
					<td><?php echo $data3['tgl_kembali'] ?></td>
					<?php 
					if($data3['tgl_kembali1'] == '0000-00-00 00:00:00'){
						$tgl_kembali1 = "Barang Belum dikembalikan";
					}else{
						$tgl_kembali1 = $data3['tgl_kembali1'];
					}
					?>
					<td><?php echo $tgl_kembali1 ?></td>
					<?php 
					if($data3['status_pinjam'] == '1'){
						@$id_pem = $data3[id_peminjaman];
						$status = "Menunggu Konfirmasi Operator";
						$color = "black";
						@$kode_refferal = " ( ".$data3[id_peminjaman]." ) ";
					}else if($data3['status_pinjam'] == '2'){
						@$id_pem = $data3[id_peminjaman];
						$status = "Dikonfirmasi Silahkan Ambil Barang di Gudang";
						$color = "grey";
						@$kode_refferal = " ( ".$data3[id_peminjaman]." ) ";
					}else if($data3['status_pinjam'] == '3'){
						$status = "Barang Sedang dipinjam  ";
						$color = "blue";
						@$kode_refferal = " ( ".$data3[id_peminjaman]." ) ";
					}else if($data3['status_pinjam'] == '4'){
						$status = "Barang Sudah dikembalikan ";
						$color = "green";
						$kode_refferal = "";
					}else if($data3['status_pinjam'] == '5'){
						$status = "Barang Rusak dan Butuh Perbaikan ";
						$color = "red";
						$kode_refferal = "";
					}else if($data3['status_pinjam'] == '6'){
						$status = "Barang Sudah diperbaiki dan Butuh Pengecekan Operator ";
						$color = "grey";
						$kode_refferal = "";
					}
					?>
					<td style="color: <?php echo $color; ?>; "><strong><?php echo $status.$kode_refferal ?></strong></td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Barang</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Barang</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th>Jumlah</th>
					<th>Ruangan</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$isi = $perintah->tampilbarang($con);
					foreach ($isi as $data4) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data4['id_inventaris'] ?></td>
					<td><?php echo $data4['nama'] ?></td>
					<td><?php echo $data4['keterangan'] ?></td>
					<td><?php echo $data4['jumlah'] ?></td>
					<td><?php echo $data4['nama_ruang'] ?></td>
					<?php 
						if($data4['status'] == 1){
							$status = 'Menunggu Konfirmasi Petugas Gudang';
						}else if($data4['status'] == 2){
							$status = 'Barang Sedang dikirimkan Ke Gudang';
						}else if($data4['status'] == 3){
							$status = 'Barang Tersedia di Gudang';
						}else if($data4['status'] == 4){
							$status = 'Barang Sedang dipinjam';
						}else if($data4['status'] == 5){
							$status = 'Barang dilaporkan Rusak';
						}else if($data4['status'] == 6){
							$status = 'Barang Sedang diperbaiki';
						}

					?>
					<td><?php echo $status ?></td>
					<td><a href="?page=peminjaman&pinjam&id=<?php echo $data4['id_inventaris'] ?>" class=" btn btn-success">Pinjam</a> &nbsp; 
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Peminjaman</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Barang</label>
				<input type="text" class="form-control form-control-sm" name="nama" value="<?php echo @$data['nama'];?>" disabled>
			</div>
			<div class="form-group">
				<label for="">Jenis</label>
				<input type="text" class="form-control form-control-sm" name="jenis" value="<?php echo @$jenis?>" disabled>
			</div>
			<div class="form-group">
				<label for="">Jumlah</label>
				<input type="number" class="form-control form-control-sm " name="jumlah" autofocus="on" value="" <?php if($id == ''){?>disabled<?php } ?>>
			</div>
			<div class="form-group">
				<label for="">Rencana Tanggal Peminjaman</label>
				<input type="date" class="form-control col-sm-3" name="tgl_pinjam" value="" <?php if($id == ''){?>disabled<?php } ?>>
			</div>
			<div class="form-group">
				<label for="">Rencana Tanggal Pengembalian</label>
				<input type="date" class="form-control col-sm-3" name="tgl_kembali" value="" <?php if($id == ''){?>disabled<?php } ?>>
			</div>
			<br>
			<?php 
			if($id != ''){
			?>
			<button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
              <a href="?page=peminjaman" class="btn btn-danger">Cancel</a>
             <?php 
			}

			?>
              
             
		</form>
	</div>
</div>