<?php 
$disabled = 'disabled';

@$id = $_GET['id'];
@$table = "tb_inventaris";
@$where = "id_inventaris = '$id'";
@$form = "?page=ruang";

if (isset($_GET['edit'])) {
	$isi = "status ='2'";
	$edit = $perintah->update($con, $table, $isi, $where, $form);

}

if (isset($_GET['edit1'])) {
	$isi = "status ='3'";
	$edit = $perintah->update($con, $table, $isi, $where, $form);

}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Barang</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>Ruang</th>
					<th>ID Ruang</th>
					<th>Nama Barang</th>
					<th>Keterangan</th>
					<th>Jumlah</th>
					<th>Status</th>
					<th>Konfirmasi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$tampilruang = $perintah->tampilbarang($con);
					foreach ($tampilruang as $data3) {
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['nama_ruang'] ?></td>
					<td><?php echo $data3['id_ruang'] ?></td>
					<td><?php echo $data3['nama'] ?></td>
					<td><?php echo $data3['keterangan'] ?></td>
					<td><?php echo $data3['jumlah'] ?></td>
					<?php 
						
						if($data3['status'] == 1){
							$status = 'Menunggu Konfirmasi Petugas Gudang';
							$warna = "black";
						}else if($data3['status'] == 2){
							$status = 'Barang Sedang dikirimkan Ke Gudang';
							$warna = "purple";
						}else if($data3['status'] == 3){
							$status = 'Barang Tersedia di Gudang';
							$warna = "green";
						}else if($data3['status'] == 4){
							$status = 'Barang Sedang dipinjam';
							$warna = "blue";
						}else if($data3['status'] == 5){
							$status = 'Barang dilaporkan Rusak';
							$warna = "red";
						}else if($data3['status'] == 6){
							$status = 'Barang Sedang diperbaiki';
							$warna = "yellow";
						}

					?>
					<td style="color: <?php echo $warna ?>"><strong><?php echo $status ?></strong></td>
					<td>
						<?php 
						$disabled = 'disabled';
						if($data3['status'] == 1){
						?>
							<a onclick="return confirm('Yakin Ingin Menerima Barang di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit&id=<?php echo $data3['id_inventaris'] ?>" class=" btn btn-success">Konfirmasi Barang</a> &nbsp; 
							<a onclick="return confirm('Yakin Barang Telah Sampai di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit1&id=<?php echo $data3['id_inventaris'] ?>" class="btn btn-danger disabled">Barang Sudah Sampai</a>
						<?php 
						}else if($data3['status'] == 2){
						?>
							<a onclick="return confirm('Yakin Ingin Menerima Barang di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit&id=<?php echo $data3['id_inventaris'] ?>" class=" btn btn-success disabled">Konfirmasi Barang</a> &nbsp; 
							<a onclick="return confirm('Yakin Barang Telah Sampai di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit1&id=<?php echo $data3['id_inventaris'] ?>" class="btn btn-danger">Barang Sudah Sampai</a>
						<?php 
						}else{
						?>
							<a onclick="return confirm('Yakin Ingin Menerima Barang di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit&id=<?php echo $data3['id_inventaris'] ?>" class=" btn btn-success disabled">Konfirmasi Barang</a> &nbsp; 
							<a onclick="return confirm('Yakin Barang Telah Sampai di <?php echo $data3['nama_ruang'] ?> ?')" href="?page=ruang&edit1&id=<?php echo $data3['id_inventaris'] ?>" class="btn btn-danger disabled">Barang Sudah Sampai</a>
						<?php 
						}

						?>
						
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>