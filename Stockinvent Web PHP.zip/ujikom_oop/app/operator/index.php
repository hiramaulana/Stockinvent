<?php 

error_reporting(0);

include "../../assets/config/koneksi.php";
include "../../assets/library/controller.php";
$perintah = new oop();

date_default_timezone_set("Asia/Jakarta");
$tgl_now = date('Y-m-d H:i:s');

$length = 10;
$randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZHIRAMAULANAPASTIBISA"), 0, $length);
$kode_acak = $randomString;

$cookies =  $_COOKIE['id_petugas'];

if (isset($_GET['logout'])) {
  $perintah->logout();
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Meta & CSS -->
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="../../assets/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="../../assets/font-awesome-4.7.0/css/font-awesome.min.css">

    <title>STOCKINVENT | Operator</title>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar -->
    <header class="app-header" style="background-color: #334455"><a class="app-header__logo" style="background-color: #334455; color: white; margin-top: 9px; margin-left: 2px;"><h3>STOCKINVENT</h3></a>
      <!-- Sidebar toggle button-->
      <a class="app-sidebar__toggle" href="#" data-toggle="sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
            <li><a style="margin-top: 5px; color: red;" onclick="return confirm('Are You Sure?')" class="dropdown-item" href="?logout" id="forLogout"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          
      </ul>
    </header>

    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar" style="background-color: #333444">
      <ul class="app-menu">
        <li><a class="app-menu__item <?php if($_GET['page']=='home'){ echo 'active' ?><?php } ?>" href="?page=home"><i class="app-menu__icon fa fa-home"></i><span class="app-menu__label">Home</span></a></li>
        <li><a class="app-menu__item <?php if($_GET['page']=='peminjaman'){ echo 'active' ?><?php } ?>" href="?page=peminjaman"><i class="app-menu__icon fa fa-cart-arrow-down"></i><span class="app-menu__label">Peminjaman </span></a></li>
        <li><a class="app-menu__item <?php if($_GET['page']=='pengembalian'){ echo 'active' ?><?php } ?>" href="?page=pengembalian"><i class="app-menu__icon fa fa-mail-reply-all"></i><span class="app-menu__label">Pengembalian </span></a></li>
        <li><a class="app-menu__item <?php if($_GET['page']=='ruang'){ echo 'active' ?><?php } ?>" href="?page=ruang"><i class="app-menu__icon fa fa-map-marker"></i><span class="app-menu__label">Ruang </span></a></li>
    </aside>
      
    <!-- Include Page -->
    <main class="app-content">
      <div class="row">
        <?php 
        @$page = $_GET['page'];
        switch ($page) {
          case 'home':
            include "home.php";
            break;
          case 'peminjaman':
            include "peminjaman.php";
            break;
          case 'pengembalian':
            include "pengembalian.php";
            break;          
          case 'ruang':
            include "ruang.php";
            break;          
          default:
            include "home.php";
            break;
        }
         ?>
      </div>
    </main>

    <script src="../../assets/js/jquery-3.2.1.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/main.js"></script>
    <script type="text/javascript" src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../../assets/js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#example').DataTable();</script>
    <script type="text/javascript">$('#example1').DataTable();</script>
    <script type="text/javascript">$('#example2').DataTable();</script>
  </body>
</html>