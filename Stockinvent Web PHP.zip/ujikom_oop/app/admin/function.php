<?php 

// Gambar PEGAWAI

if (isset($_POST['simpan'])) {	
	$nama_file = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
	move_uploaded_file($tmp, "../../assets/foto_pegawai/$nama_file");
	$isi = "id_pegawai = '', nip = '$nip', password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat', foto = '$nama_file'";
	$input_pegawai = $perintah->simpan($con, $table, $isi, $alert, $form);	
}

if (isset($_POST['update'])) {
	if($_GET['g'] == 'T'){
		$isi = "password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat'";
	$update_pegawai = $perintah->update($con, $table, $isi, $where, $form);
	}else{
	$nama_file = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
	move_uploaded_file($tmp, "../../assets/foto_pegawai/$nama_file");
	$isi = "password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat', foto = '$nama_file'";
	$update_pegawai = $perintah->update($con, $table, $isi, $where, $form);	
	}
}

<td><img style="width: 50px; height:50px;" src="../../assets/foto_pegawai/<?php echo $data3['foto'];?>"></td>
					<td><a href="?page=pegawai&edit&id=<?php echo $data3['id_pegawai'] ?>&g=T" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=pegawai&hapus&id=<?php echo $data3['id_pegawai'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>

if(isset($_GET['edit'])){
			?>
			<div class="form-group">
				<label for="">Foto Anda</label>
				<img class="form-control form-control-sm" style="width: 150px; height:150px;" src="../../assets/foto_pegawai/<?php echo $data['foto'];?>">
			</div>
			<h5>Ingin ganti gambar ?</h5>
			<a class="btn btn-success" href="?page=pegawai&edit&id=<?=$_GET['id']?>&g=Y">YA</a>
			<br><br>
			<?php } ?>
			<?php if(@$_GET['g'] == "Y"){ ?>
			<div class="form-group">
				<label for="">Foto</label>
				<input type="file" class="form-control form-control-sm" name="gambar" value="">
			</div>
			<?php }else if(@$_GET['g'] != "T"){ ?>
			<div class="form-group">
				<label for="">Foto</label>
				<input type="file" class="form-control form-control-sm" name="gambar" value="">
			</div>
			<?php }?>
			<br>


<!-- --------------AUDIO VIDEO -->

<video style="width: 90%; height: 90%" controls autoplay><source src="mari.mp4" type="video/mp4"></video>
			<audio controls><source src="mari.mp3" type="audio/mp3"></audio>

<!-- LOGS -->
Apache ->LOGS->access.log

?>