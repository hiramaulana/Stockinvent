<?php 

@$form = "?page=pengembalian";
@$table = "tb_peminjaman";
@$id_pegawai = $_GET['idpeg'];
@$id_peminjaman = $_GET['idpem'];
@$id_inventaris = $_GET['idinv'];
@$where = "id_peminjaman = '$id_peminjaman'";
@$tgl_now1 = date('Y-m-d');
@$disabled = disabled;
@$ket_rusak = $_POST['ket_rusak'];

if (isset($_GET['edit'])) {
	$sql3 = mysqli_query($con, "SELECT tb_inventaris.*, tb_peminjaman.*, tb_pegawai.*, tb_detail_pinjam.* from tb_inventaris 
						join tb_peminjaman 
						on 
						tb_peminjaman.id_inventaris = tb_inventaris.id_inventaris
						join tb_pegawai
						on
						tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai
						join tb_detail_pinjam
						on
						tb_peminjaman.id_peminjaman = tb_detail_pinjam.id_peminjaman 
						where 
						tb_peminjaman.id_peminjaman = tb_detail_pinjam.id_peminjaman");
	$data = mysqli_fetch_array($sql3);
}

if (isset($_POST['update'])) {
	@$jumlah_rusak = $_POST[jumlah_rusak];
	if($jumlah_rusak == '' || $jumlah_rusak == 0){

		$isi = "tgl_kembali1 = '$tgl_now', status_pinjam = '4'";
		$update_pinjam = $perintah->update($con, $table, $isi, $where, $form);

		$table1 = "tb_detail_pinjam";
		$hapus_detail = $perintah->hapus($con, $table1, $where, $form);

	}else{
		@$jumlah = $_POST[jumlah];
		$total_jumlah = $jumlah - $jumlah_rusak;

		$isi1 = "tgl_kembali1 = '$tgl_now', status_pinjam = '5'";
		$update_pinjam = $perintah->update($con, $table, $isi1, $where, $form);

		$isi2 = "jumlah = jumlah+$total_jumlah";
		$where2 = "id_inventaris = '$id_inventaris'";
		$table2 = "tb_inventaris";
		$update_invent = $perintah->update($con, $table2, $isi2, $where2, $form);

		$isi3 = "id_maintenance = '', id_inventaris = '$id_inventaris', ket_rusak = '$ket_rusak', jumlah = '$jumlah', jumlah_rusak = '$jumlah_rusak', id_peminjaman = '$id_peminjaman', status_perb = '1', biaya= ''";
		$table3 = "tb_maintenance";
		$alert = "Data Barang Berhasil dimasukan ";
		$insert_rusak = $perintah->simpan($con, $table3, $isi3, $alert, $from);		
	}
	
}

	
 ?> 
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Peminjaman</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<style type="text/css">
				.hide{
					display: none;
				}
			</style>
			<thead>
				<tr>
					<th>ID Peminjaman</th>
					<th class="hide">NIP</th>
					<th>Nama Pegawai</th>
					<th>Nama Barang</th>
					<th>Jumlah Peminjaman</th>
					<th>Tanggal Peminjaman</th>
					<th>Tanggal Pengembalian</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$tampil_pinjam = $perintah->tampilpeminjaman($con);
						foreach ($tampil_pinjam as $data1) { 
						$no++
				?>
				<tr>
					<td><?php echo $data1['id_peminjaman'] ?></td>
					<td class="hide"><?php echo $data1['nip'] ?></td>
					<td><?php echo $data1['nama_pegawai'] ?></td>
					<td><?php echo $data1['nama'] ?></td>
					<td><?php echo $data1['jumlah'] ?></td>
					<td><?php echo $data1['tgl_pinjam'] ?></td>
					<?php 
					if($data1['tgl_kembali1'] == '0000-00-00 00:00:00'){
						$tgl_kembali1 = "Barang Belum dikembalikan";
					}else{
						$tgl_kembali1 = $data1['tgl_kembali1'];
					}
					?>
					<td><?php echo $tgl_kembali1 ?></td>
					<?php 
					if($data1['status_pinjam'] == '1'){
						$status = "Menunggu Konfirmasi Operator";
						$color = "black";
						@$kode_refferal = "(".$data1[id_peminjaman].")";
					}else if($data1['status_pinjam'] == '2'){
						$status = "Dikonfirmasi Silahkan Ambil Barang di Gudang";
						$color = "grey";
						$kode_refferal = "";
					}else if($data1['status_pinjam'] == '3'){
						$status = "Barang Sedang dipinjam  ";
						$color = "blue";
						$kode_refferal = "";
					}else if($data1['status_pinjam'] == '4'){
						$status = "Barang Sudah dikembalikan ";
						$color = "green";
						$kode_refferal = "";
					}else if($data1['status_pinjam'] == '5'){
						$status = "Barang Rusak dan Butuh Perbaikan ";
						$color = "red";
						$kode_refferal = "";
					}else if($data1['status_pinjam'] == '6'){
						$status = "Barang Sudah diperbaiki dan Butuh Pengecekan Operator ";
						$color = "grey";
						$kode_refferal = "";
					}
					?>
					<td style="color: <?php echo $color; ?>; "><strong><?php echo $status.$kode_refferal ?></strong></td>
					<td>
						<?php 
						$idpeg = $data1['id_pegawai'];
						$idpem = $data1['id_peminjaman'];
						$idinv = $data1['id_inventaris'];
						if($data1['status_pinjam'] == '4' || $data1['status_pinjam'] == '5' || $data1['status_pinjam'] == '1' || $data1['status_pinjam'] == '2'){
						?>
							<a href="?page=pengembalian&edit&idpeg=<?php echo $idpeg ?>&idpem=<?php echo $idpem ?>&idinv=<?php echo $idinv ?>" class="btn btn-success disabled"><i class="fa fa-pencil"></i></a>
						<?php 
						}else{
						?>
							<a href="?page=pengembalian&edit&idpeg=<?php echo $idpeg ?>&idinv=<?php echo $idinv ?>&idpem=<?php echo $idpem ?>" class="btn btn-success"><i class="fa fa-pencil"></i></a>
						<?php 
						}
						?>
							
					</td>	
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Update Data Peminjaman</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="" >ID Peminjaman</label>
				<input type="text" class="form-control form-control-sm" name="id_peminjaman" value="<?php echo @$data['id_peminjaman'];?>" disabled>
			</div>
			<div class="form-group">
				<label for="">Nama</label>
				<input type="text" class="form-control form-control-sm" name="nip" value="<?php echo @$data['nama_pegawai'];?>" disabled>
			</div>
			<div class="form-group">
				<label for="">Barang</label>
				<input type="text" class="form-control form-control-sm" name="barang" value="<?php echo @$data['nama'];?>" disabled>
			</div>
			<div class="form-group" style="float: left">
				<label for="">Tanggal Peminjaman</label>
				<input type="text" class="form-control col-sm-12" name="tgl_pinjam" value="<?php echo @$data['tgl_pinjam'];?>" disabled>
			</div>
			<div class="form-group" style="float: center">
				<label for="">Tanggal Rencana Pengembalian</label>
				<input type="text" class="form-control col-sm-3" name="tgl_pinjam" value="<?php echo @$data['tgl_kembali'];?>" disabled>
			</div>
			<div class="form-group" style="float: center">
				<label for="">Tanggal Sekarang</label>
				<input type="text" class="form-control col-sm-2" name="tgl_pinjam" value="<?php echo @$tgl_now1;?>" disabled>
			</div>
			<div class="form-group">
				<label for="">Jumlah</label>
				<input type="text" class="form-control form-control-sm" name="jumlah" value="<?php echo @$data['jumlah'] ?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Jumlah Barang Rusak</label>
				<?php 
					if(@$_GET['idpem'] == ''){
						@$disabled = disabled;
					}else {
						@$disabled = "";
					}
					?>
				<input type="number" class="form-control form-control-sm" name="jumlah_rusak" autofocus="on" value="" placeholder="0" <?php echo @$disabled ?>> 
			</div>
			<div class="form-group">
				<label for="">Keterangan Rusak</label>
				<input type="text" placeholder="Optional Jika Barang Rusak" class="form-control form-control-sm" name="ket_rusak" value="" <?php echo $disabled ?>>
			</div>
			<br>
			<div class="form-group">
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-primary" style="color: white"><i class="fa fa-check" style="color: white"></i> Selesai</button>
                  <a href="?page=pengembalian" class="btn btn-danger">Cancel</a>
            <?php endif ?>
             </div>
		</form>
	</div>
</div>
