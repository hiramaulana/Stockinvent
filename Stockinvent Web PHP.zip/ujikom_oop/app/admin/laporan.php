<?php 

if (isset($_POST['print'])) {
	$id = $_POST['jenis'];
	echo "<script>document.location.href='print_laporan.php?id=$id'</script>";
}
	
?>
<div class="col-sm-12">
	<div class="tile">
		<h3>Cetak Laporan</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Jenis Laporan</label>
				<select name="jenis" class="form-control">
					<option value="1">Barang</option>
					<option value="2">Peminjaman</option>
					<option value="3">Pengembalian</option>
					<option value="4">Peminajaman & Pengembalian</option>
					<option value="5">Maintenanace</option>
					<option value="6">Ruangan</option>
					<option value="7">Petugas</option>
					<option value="8">Pegawai</option>
				</select>
			</div>
			<br>
           	<button target="_blank" type="submit" name="print" class="btn btn-primary"><i class="fa fa-download"></i> Print</button>
		</form>
	</div>
</div>