<?php 

@$idpem = $_GET['idpem'];
@$table = "tb_peminjaman";
@$barang = $_POST['barang'];
@$jumlah = $_POST['jumlah'];
@$tgl_kembali = $_POST['tgl_kembali'];
@$form = "?page=peminjaman";

if (isset($_GET['edit1'])) {
	$sql11 = mysqli_query($con, "UPDATE tb_peminjaman set status_pinjam = '2' where id_peminjaman = '$idpem'");
	if($sql11){
		echo "<script>alert('Data Peminjaman Berhasil Dikonfirmasi ');document.location.href='?page=peminjaman'</script>";
	}

}

if (isset($_GET['edit2'])) {
	$sql11 = mysqli_query($con, "UPDATE tb_peminjaman set status_pinjam = '3' where id_peminjaman = '$idpem'");
	if($sql11){
		echo "<script>alert('Barang Berhasil dipinjam ');document.location.href='?page=peminjaman'</script>";
	}

}

if (isset($_POST['simpan'])) {

	$table1 = "tb_pegawai";
	$where1 = "nip = '$_POST[nip]'";
	$pegawai = $perintah->edit($con, $table1, $where1);
	foreach ($pegawai as $pegawai) {}
		$pegawai1 = $pegawai['id_pegawai'];
	if($pegawai != ''){
		$alert = "Data Peminjaman Berhasil Diinput";
		$id_peminjaman = $kode_acak;		
		$isi = "id_peminjaman = '$id_peminjaman', id_inventaris = '$barang', jumlah = '$jumlah', tgl_pinjam = '$tgl_now', tgl_kembali = '$tgl_kembali', tgl_kembali1 = '', status_pinjam = '3', id_pegawai = '$pegawai1'";
		$input_peminjaman = $perintah->simpan($con, $table, $isi, $alert, $form);
		$table1 = "tb_detail_pinjam";
		$isi1 = "id_detail_pinjam = '', id_inventaris = '$barang', id_peminjaman = '$id_peminjaman', jumlah = '$jumlah'";
		$input_detail_pinjam = $perintah->simpan($con, $table1, $isi1, $alert, $form);
	}
}

if (isset($_POST['update'])) {
	$sql7 = "update tb_inventaris set id_ruang = '$_POST[ruang]', id_jenis = '$_POST[jenis]', nama = '$_POST[nama]', jumlah = '$_POST[jumlah]', keterangan = '$_POST[keterangan]' where id_inventaris = '$_GET[id]'";
	$query7 = mysqli_query($con, $sql7);
	if ($query7) {
		echo "<script>alert('Data Berhasil diupdate');document.location.href='?page=inventarisir'</script>";
	}
}

if (isset($_GET['hapus'])) {
	$sql8 = "delete from tb_inventaris where id_inventaris = '$_GET[id]'";
	$query8 = mysqli_query($con, $sql8);
	if ($query8) {
		echo "<script>alert('Data Berhasil dihapus');document.location.href='?page=inventarisir'</script>";
	}
}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Peminjaman</h3>
		<hr>
		<table class="table table-bordered" id="example1">
			<style type="text/css">
				.hide{
					display: none;
				}
			</style>
			<thead>
				<tr>
					<th>ID</th>
					<th class="hide">NIP</th>
					<th>Nama Pegawai</th>
					<th>Nama Barang</th>
					<th>Jumlah Peminjaman</th>
					<th>Tanggal Peminjaman</th>
					<th>Tanggal Rencana Pengembalian</th>
					<th>Tanggal Pengembalian</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$isi = $perintah->tampilpeminjaman($con);
					foreach ($isi as $data2) { 
				?>
				<tr>
					<td><?php echo $data2['id_peminjaman'] ?></td>
					<td class="hide"><?php echo $data2['nip'] ?></td>
					<td><?php echo $data2['nama_pegawai'] ?></td>
					<td><?php echo $data2['nama'] ?></td>
					<td><?php echo $data2['jumlah'] ?></td>
					<td><?php echo $data2['tgl_pinjam'] ?></td>
					<td><?php echo $data2['tgl_kembali'] ?></td>
					<?php 
					if($data2['tgl_kembali1'] == '0000-00-00 00:00:00'){
						$tgl_kembali1 = "Barang Belum dikembalikan";
					}else{
						$tgl_kembali1 = $data2['tgl_kembali1'];
					}
					?>
					<td><?php echo $tgl_kembali1 ?></td>
					<?php 
					if($data2['status_pinjam'] == '1'){
						@$id_pem = $data2[id_peminjaman];
						$status = "Menunggu Konfirmasi Operator";
						$color = "black";
						@$kode_refferal = "<a onclick= return confirm(Are You Sure?) style=color:white;background-color:blue;border-radius:5px; href=?page=peminjaman&edit1&idpem=$id_pem>ACC</a>";
					}else if($data2['status_pinjam'] == '2'){
						@$id_pem = $data2[id_peminjaman];
						$status = "Dikonfirmasi Silahkan Ambil Barang di Gudang";
						$color = "grey";
						@$kode_refferal = "<a style=color:white;background-color:blue;border-radius:5px; href=?page=peminjaman&edit2&idpem=$id_pem>ACC</a>";
					}else if($data2['status_pinjam'] == '3'){
						$status = "Barang Sedang dipinjam  ";
						$color = "blue";
						$kode_refferal = "";
					}else if($data2['status_pinjam'] == '4'){
						$status = "Barang Sudah dikembalikan ";
						$color = "green";
						$kode_refferal = "";
					}else if($data2['status_pinjam'] == '5'){
						$status = "Barang Rusak dan Butuh Perbaikan ";
						$color = "red";
						$kode_refferal = "";
					}else if($data2['status_pinjam'] == '6'){
						$status = "Barang Sudah diperbaiki dan Butuh Pengecekan Operator ";
						$color = "grey";
						$kode_refferal = "";
					}
					?>
					<td style="color: <?php echo $color; ?>; "><strong><?php echo $status." ".$kode_refferal ?></strong></td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Barang Yang Tersedia</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Barang</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th>Jumlah</th>
					<th>Ruangan</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$isi = $perintah->tampilbarang1($con);
					foreach ($isi as $data1) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data1['id_inventaris'] ?></td>
					<td><?php echo $data1['nama'] ?></td>
					<td><?php echo $data1['keterangan'] ?></td>
					<td><?php echo $data1['jumlah'] ?></td>
					<td><?php echo $data1['nama_ruang'] ?></td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>

<div class="col-sm-12">
	<div class="tile">
		<h3>Input Peminjaman </h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Barang</label>
				<select name="barang" class="form-control">
					
					<?php 
						$isi = $perintah->tampilbarang1($con);
						foreach ($isi as $data2) { 
					?>
					<option value="<?php echo $data2['id_inventaris'] ?>"><?php echo $data2['nama']?></option>
					<?php 
						}

					?>
				</select>
			</div>
			<div class="form-group">
				<label for="">NIP</label>
				<input type="number" class="form-control form-control-sm" name="nip" value="">
			</div>
			<div class="form-group">
				<label for="">Jumlah</label>
				<input type="text" class="form-control form-control-sm" name="jumlah" value="">
			</div>
			<div class="form-group">
				<label for="">Rencana Tanggal Pengembalian</label>
				<input type="date" class="form-control col-sm-3" name="tgl_kembali" value="">
			</div>
			<br>
			<div class="form-group">
          		<button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             </div>
		</form>
	</div>
</div>
