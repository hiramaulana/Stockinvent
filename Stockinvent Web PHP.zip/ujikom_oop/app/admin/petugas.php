<?php 

@$id = $_GET['id'];
@$table = "tb_petugas";
@$where = "id_petugas = '$id'";
@$form = "?page=petugas";
@$nama_petugas = $_POST['nama'];
@$username = $_POST['username'];
@$password = $_POST['password'];
@$id_level = $_POST['id_level'];
@$alert = "Input Petugas Berhasil";

if (isset($_GET['edit'])) {
	$focus = "autofocus=on";
	$edit0 = $perintah->edit($con, $table, $where);
	foreach ($edit0 as $data) {}
		if($data['id_level'] == '1'){
			$id_level1 = "Administrator";
		}else if($data['id_level'] == '2'){
			$id_level1 = "Operator";
		}else{
			$id_level1 = "Terjadi Kesalahan";
		}

}

if (isset($_POST['simpan'])) {	
	$isi = "id_petugas = '', username = '$username', password = '$password', nama_petugas = '$nama_petugas', id_level = '$id_level'";
	$input_petugas = $perintah->simpan($con, $table, $isi, $alert, $form);	
}

if (isset($_POST['update'])) {
	$isi = "username = '$username', password = '$password', nama_petugas = '$nama_petugas', id_level = '$id_level'";
	$update_petugas = $perintah->update($con, $table, $isi, $where, $form);	
}

if (isset($_GET['hapus'])) {
	$hapus_petugas = $perintah->hapus($con, $table, $where, $form);	
}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Ruangan</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Petugas</th>
					<th>Nama</th>
					<th>Username</th>
					<th>Password</th>
					<th>Level</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$edit1 = $perintah->tampil($con, $table);
					foreach ($edit1 as $data3) {
						$no++;
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['id_petugas'] ?></td>
					<td><?php echo $data3['nama_petugas'] ?></td>
					<td><?php echo $data3['username'] ?></td>
					<td><?php echo $data3['password'] ?></td>
					<?php 
						if($data3['id_level'] == 1){
							$status = "Administrator";
						}else{
							$status = "Operator";
						}
					?>
					<td><?php echo $status ?></td>
					<td><a href="?page=petugas&edit&id=<?php echo $data3['id_petugas'] ?>" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=petugas&hapus&id=<?php echo $data3['id_petugas'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Petugas</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Petugas</label>
				<input type="text" <?php echo @$focus ?> class="form-control form-control-sm" name="nama" value="<?php echo @$data['nama_petugas'];?>">
			</div>
			<div class="form-group">
				<label for="">Username</label>
				<input type="text" class="form-control form-control-sm" name="username" value="<?php echo @$data['username'] ?>">
			</div>
			<div class="form-group">
				<label for="">Password</label>
				<input type="text" class="form-control form-control-sm" name="password" value="<?php echo @$data['password'] ?>">
			</div>
			<div class="form-group">
				<label for="">Level</label>
				<select name="id_level" class="form-control">
					<option value="<?php echo @$data['id_level'] ?>"><?php echo @$id_level1 ?></option>
					<option value="<?php echo '1' ?>">Administrator</option>
					<option value="<?php echo '2' ?>">Operator</option>
				</select>
			</div>
			<br>
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-warning" style="color: white"><i class="fa fa-check" style="color: white"></i> Update</button>
                  <a href="?page=petugas" class="btn btn-danger">Cancel</a>
            <?php endif ?>
            <?php if (!isset($_GET['edit'])): ?>  
                      <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             <?php endif ?>
		</form>
	</div>
</div>