<?php 

@$id = $_GET['id'];
@$table = "tb_pegawai";
@$where = "id_pegawai = '$id'";
@$form = "?page=pegawai";
@$nama_pegawai = $_POST['nama'];
@$nip = $_POST['nip'];
@$password = $_POST['password'];
@$alamat = $_POST['alamat'];
@$alert = "Input Petugas Berhasil";
@$foto = $_POST['gambar'];

if (isset($_GET['edit'])) {
	$focus = "autofocus=on";
	$disabled = 'disabled';
	$edit0 = $perintah->edit($con, $table, $where);
	foreach ($edit0 as $data) {}

}

if (isset($_POST['simpan'])) {	
	$nama_file = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
	move_uploaded_file($tmp, "../../assets/foto_pegawai/$nama_file");
	$isi = "id_pegawai = '', nip = '$nip', password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat', foto = '$nama_file'";
	$input_pegawai = $perintah->simpan($con, $table, $isi, $alert, $form);	
}

if (isset($_POST['update'])) {
	if($_GET['g'] == 'T'){
		$isi = "password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat'";
	$update_pegawai = $perintah->update($con, $table, $isi, $where, $form);
	}else{
	$nama_file = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
	move_uploaded_file($tmp, "../../assets/foto_pegawai/$nama_file");
	$isi = "password = '$password', nama_pegawai = '$nama_pegawai', alamat = '$alamat', foto = '$nama_file'";
	$update_pegawai = $perintah->update($con, $table, $isi, $where, $form);	
	}
}

if (isset($_GET['hapus'])) {
	$hapus_pegawai = $perintah->hapus($con, $table, $where, $form);	
}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Pegawai</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Pegawai</th>
					<th>Nama Pegawai</th>
					<th>NIP</th>
					<th>Password</th>
					<th>Alamat</th>
					<th>foto</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$edit1 = $perintah->tampil($con, $table);
					foreach ($edit1 as $data3) {
						$no++;
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['id_pegawai'] ?></td>
					<td><?php echo $data3['nama_pegawai'] ?></td>
					<td><?php echo $data3['nip'] ?></td>
					<td><?php echo $data3['password'] ?></td>
					<td><?php echo $data3['alamat'] ?></td>
					<td><img style="width: 50px; height:50px;" src="../../assets/foto_pegawai/<?php echo $data3['foto'];?>"></td>
					<td><a href="?page=pegawai&edit&id=<?php echo $data3['id_pegawai'] ?>&g=T" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=pegawai&hapus&id=<?php echo $data3['id_pegawai'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Pegawai</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Pegawai</label>
				<input type="text" <?php echo @$focus ?> class="form-control form-control-sm" name="nama" value="<?php echo @$data['nama_pegawai'];?>">
			</div>
			<div class="form-group">
				<label for="">NIP</label>
				<input type="number" class="form-control form-control-sm" name="nip" value="<?php echo @$data['nip'] ?>" <?php echo @$disabled ?>>
			</div>
			<div class="form-group">
				<label for="">Password</label>
				<input type="text" class="form-control form-control-sm" name="password" value="<?php echo @$data['password'] ?>">
			</div>
			<div class="form-group">
				<label for="">Alamat</label>
				<input type="text" class="form-control form-control-sm" name="alamat" value="<?php echo @$data['alamat'] ?>">
			</div>
			<?php 
			if(isset($_GET['edit'])){
			?>
			<div class="form-group">
				<label for="">Foto Anda</label>
				<img class="form-control form-control-sm" style="width: 150px; height:150px;" src="../../assets/foto_pegawai/<?php echo $data['foto'];?>">
			</div>
			<h5>Ingin ganti gambar ?</h5>
			<a class="btn btn-success" href="?page=pegawai&edit&id=<?=$_GET['id']?>&g=Y">YA</a>
			<br><br>
			<?php } ?>
			<?php if(@$_GET['g'] == "Y"){ ?>
			<div class="form-group">
				<label for="">Foto</label>
				<input type="file" class="form-control form-control-sm" name="gambar" value="">
			</div>
			<?php }else if(@$_GET['g'] != "T"){ ?>
			<div class="form-group">
				<label for="">Foto</label>
				<input type="file" class="form-control form-control-sm" name="gambar" value="">
			</div>
			<?php }?>
			<br>
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-warning" style="color: white"><i class="fa fa-check" style="color: white"></i> Update</button>
                  <a href="?page=pegawai" class="btn btn-danger">Cancel</a>
            <?php endif ?>
            <?php if (!isset($_GET['edit'])): ?>  
                      <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             <?php endif ?>
		</form>
	</div>
</div>