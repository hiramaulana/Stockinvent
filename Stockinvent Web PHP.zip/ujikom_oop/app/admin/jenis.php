<?php 

@$id = $_GET['id'];
@$table = "tb_jenis";
@$where = "id_jenis = '$id'";
@$form = "?page=jenis";
@$nama_jenis = $_POST['nama'];
@$keterangan = $_POST['keterangan'];
@$alert = "Input Jenis Berhasil";

if (isset($_GET['edit'])) {
	$focus = "autofocus=on";
	$edit0 = $perintah->edit($con, $table, $where);
	foreach ($edit0 as $data) {}
	$jenis = $data['nama_jenis'];

}

if (isset($_POST['simpan'])) {	
	$length = 2;
	$randomString1 = substr(str_shuffle("HIRAMAULANAPASTIBISABISBCDEFGJKLMNOQUVWXYZ"), 0, $length);
	$kd_jenis = $randomString1;
	$isi = "id_jenis = '', nama_jenis = '$nama_jenis', keterangan = '$keterangan', kd_jenis = '$kd_jenis'";
	$input_jenis = $perintah->simpan($con, $table, $isi, $alert, $form);	
}

if (isset($_POST['update'])) {
	$isi = "nama_jenis = '$nama_jenis', keterangan = '$keterangan'";
	$update_jenis = $perintah->update($con, $table, $isi, $where, $form);	
}

if (isset($_GET['hapus'])) {
	$hapus_jenis = $perintah->hapus($con, $table, $where, $form);	
}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Jenis</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Jenis</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$edit1 = $perintah->tampil($con, $table);
					foreach ($edit1 as $data3) {
						$no++;
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['id_jenis'] ?></td>
					<td><?php echo $data3['nama_jenis'] ?></td>
					<td><?php echo $data3['keterangan'] ?></td>
					<td><a href="?page=jenis&edit&id=<?php echo $data3['id_jenis'] ?>" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=jenis&hapus&id=<?php echo $data3['id_jenis'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Jenis</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Jenis</label>
				<input type="text" <?php echo @$focus ?> class="form-control form-control-sm" name="nama" value="<?php echo @$jenis;?>">
			</div>
			<div class="form-group">
				<label for="">Keterangan</label>
				<input type="text" class="form-control form-control-sm" name="keterangan" value="<?php echo @$data['keterangan'] ?>">
			</div>
			<br>
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-warning" style="color: white"><i class="fa fa-check" style="color: white"></i> Update</button>
                  <a href="?page=jenis" class="btn btn-danger">Cancel</a>
            <?php endif ?>
            <?php if (!isset($_GET['edit'])): ?>  
                      <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             <?php endif ?>
		</form>
	</div>
</div>