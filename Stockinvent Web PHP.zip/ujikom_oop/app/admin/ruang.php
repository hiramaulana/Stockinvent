<?php 

@$id = $_GET['id'];
@$table = "tb_ruang";
@$where = "id_ruang = '$id'";
@$form = "?page=ruang";
@$nama_ruang = $_POST['nama'];
@$status = $_POST['status'];
@$keterangan = $_POST['keterangan'];
@$alert = "Input Ruangan Berhasil";

if (isset($_GET['edit'])) {
	$focus = "autofocus=on";
	$edit0 = $perintah->edit($con, $table, $where);
	foreach ($edit0 as $data) {}
	$status1 = $data['status'];
	$ruang = $data['nama_ruang'];

}

if (isset($_POST['simpan'])) {	
	$length = 2;
	$randomString1 = substr(str_shuffle("HIRAMAULANAPASTIBISABISBCDEFGJKLMNOQUVWXYZ"), 0, $length);
	$kd_ruang = $randomString1;
	$isi = "id_ruang = '', nama_ruang = '$nama_ruang', keterangan = '$keterangan', status = '$status', kd_ruang = '$kd_ruang'";
	$input_ruang = $perintah->simpan($con, $table, $isi, $alert, $form);	
}

if (isset($_POST['update'])) {
	$isi = "nama_ruang = '$nama_ruang', keterangan = '$keterangan', status = '$status'";
	$update_ruang = $perintah->update($con, $table, $isi, $where, $form);	
}

if (isset($_GET['hapus'])) {
	$hapus_ruang = $perintah->hapus($con, $table, $where, $form);	
}
	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Ruangan</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Ruang</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$edit1 = $perintah->tampil($con, $table);
					foreach ($edit1 as $data3) {
						$no++;
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['id_ruang'] ?></td>
					<td><?php echo $data3['nama_ruang'] ?></td>
					<td><?php echo $data3['keterangan'] ?></td>
					<td><?php echo $data3['status'] ?></td>
					<td><a href="?page=ruang&edit&id=<?php echo $data3['id_ruang'] ?>" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=ruang&hapus&id=<?php echo $data3['id_ruang'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Ruang</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Ruang</label>
				<input type="text" <?php echo @$focus ?> class="form-control form-control-sm" name="nama" value="<?php echo @$ruang;?>">
			</div>
			<div class="form-group">
				<label for="">Keterangan</label>
				<input type="text" class="form-control form-control-sm" name="keterangan" value="<?php echo @$data['keterangan'] ?>">
			</div>
			<div class="form-group">
				<label for="">Status</label>
				<select name="status" class="form-control">
					<option value="<?php echo @$data['status'] ?>"><?php echo @$status1 ?></option>
					<option value="<?php echo 'Tersedia' ?>">Tersedia</option>
					<option value="<?php echo 'Penuh' ?>">Penuh</option>
					<option value="<?php echo 'Maintenance' ?>">Maintenance</option>
				</select>
			</div>
			<br>
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-warning" style="color: white"><i class="fa fa-check" style="color: white"></i> Update</button>
                  <a href="?page=ruang" class="btn btn-danger">Cancel</a>
            <?php endif ?>
            <?php if (!isset($_GET['edit'])): ?>  
                      <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             <?php endif ?>
		</form>
	</div>
</div>