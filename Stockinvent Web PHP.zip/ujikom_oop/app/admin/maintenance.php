<?php 

@$id_inventaris = $_GET['idinv'];
@$id_peminjaman = $_GET['idpem'];
@$id_maintenance = $_GET['id'];
@$form = "?page=maintenance";
@$table = "tb_maintenance";
@$where = "id_maintenance = '$id_maintenance'";
@$biaya = $_POST['biaya'];

if (isset($_GET['edit1'])) {
	$isi = "status_perb = '2'";
	$sql = $perintah->update($con, $table, $isi, $where, $form);
}

if (isset($_GET['edit2'])) {
	$isi = "status_perb = '3'";
	$sql = $perintah->update($con, $table, $isi, $where, $form);
}

if (isset($_GET['edit3'])) {
	$tampil = $perintah->tampilmaintenance($con);
	foreach ($tampil as $data1) {}
	
}

if(isset($_POST['update'])){
	@$jumlah = $_POST[jumlah_rusak];
	@$jumlah_total = $_POST[jumlah_barang] - $jumlah;

	$isi = "status_perb = '4', biaya = '$biaya'";
	$update_maintenance = $perintah->update($con, $table, $isi, $where, $form);

	$table1 = "tb_inventaris";
	$isi1 = "jumlah = jumlah-$jumlah_total";
	$where1 = "id_inventaris = '$id_inventaris'";
	$update_invent = $perintah->update($con, $table1, $isi1, $where1, $form);
	
	
	$table2 = "tb_peminjaman";
	$isi2 = "status_pinjam = '4'";
	$where2 = "id_peminjaman = '$id_peminjaman'";
	$update_pinjam = $perintah->update($con, $table2, $isi2, $where2, $form);

	$table3 = "tb_detail_pinjam";
	$where3 = "id_peminjaman = '$id_peminjaman'";
	$hapus_detail = $perintah->hapus($con, $table3, $where3, $form);
}

	
 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Maintenance</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID</th>
					<th>Nama Barang</th>
					<th>Keterangan Rusak</th>
					<th>Jumlah Barang Rusak</th>
					<th>Peminjam</th>
					<th>Status</th>
					<th>Biaya</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$sql3 = mysqli_query($con, "SELECT tb_maintenance.*, tb_inventaris.*, tb_peminjaman.*, tb_pegawai.* from tb_inventaris 
						join tb_maintenance
						on
						tb_maintenance.id_inventaris = tb_inventaris.id_inventaris
						join tb_peminjaman 
						on 
						tb_peminjaman.id_peminjaman = tb_maintenance.id_peminjaman
						join tb_pegawai
						on
						tb_peminjaman.id_pegawai = tb_pegawai.id_pegawai");
					while ($data3 = mysqli_fetch_array($sql3)) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data3['id_maintenance'] ?></td>
					<td><?php echo $data3['nama'] ?></td>
					<td><?php echo $data3['ket_rusak'] ?></td>
					<td><?php echo $data3['jumlah_rusak'] ?></td>
					<td><?php echo $data3['nama_pegawai'] ?></td>
					<?php 
					if($data3['status_perb'] == '1'){
						$status = "Segera Kirim Ke Bengkel Untuk diperbaiki";
						$edit0 = "edit1";
						$confirm = "Konfirmasi!!! Barang Telah dikirim ke Bengkel ?";
					}else if($data3['status_perb'] == '2'){
						$status = "Barang Sedang diperbaiki Oleh Bengkel";
						$edit0 = "edit2";
						$confirm = "Konfirmasi!!! Barang Selesai diperbaiki dan Butuh Pengecekan Operator ?";
					}else if($data3['status_perb'] == '3'){
						$status = "Selesai diperbaiki dan Butuh Pengecekan Operator";
						$edit0 = "edit3";
						$confirm = "Konfirmasi!!! Barang Selesai diperbaiki dan Siap Kembali ke Gudang ?";
					}else if($data3['status_perb'] == '4'){
						$status = "Barang Selesai diperbaiki dan Sudah Kembali Ke Gudang";
						$edit0 = "edit4";
					}
					?>
					<td><?php echo $status ?></td>
					<?php 
					if($data3['biaya'] == '' || $data3['biaya'] == 0 ){
						$biaya1 = "Belum Selesai diperbaiki";
					}else{
						$biaya1 = $data3['biaya'];
					}
					?>
					<td><?php echo $biaya1 ?></td>
					<?php 
					if($data3['status_perb'] == '4'){
					?>
					<td><a onclick="return confirm('<?php echo $confirm ?>')" href="?page=maintenance&<?php echo $edit0; ?>&id=<?php echo $data3['id_maintenance'] ?>" class=" btn btn-success disabled"><i class="fa fa-pencil"></i></a> &nbsp; 
					</td>
					<?php 
					}else{
					?>
					<td><a onclick="return confirm('<?php echo $confirm ?>')" href="?page=maintenance&<?php echo $edit0; ?>&id=<?php echo $data3['id_maintenance'] ?>&idinv=<?php echo $data3['id_inventaris'] ?>&idpem=<?php echo $data3['id_peminjaman'] ?>" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					</td>
					<?php
					}
					?>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<?php if (isset($_GET['edit3'])): ?>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Data Maintenance</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Nama Barang</label>
				<input type="text" class="form-control form-control-sm" name="nama" value="<?php echo @$data1['nama'];?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Jumlah Barang dipinjam</label>
				<input type="text" class="form-control form-control-sm" name="jumlah_barang" value="<?php echo @$data1['jumlah'] ?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Jumlah Rusak</label>
				<input type="text" class="form-control form-control-sm" name="jumlah_rusak" value="<?php echo @$data1['jumlah_rusak'] ?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Keterangan Rusak</label>
				<input type="text" class="form-control form-control-sm" name="keterangan" value="<?php echo @$data1['ket_rusak'] ?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Peminjam</label>
				<input type="text" class="form-control form-control-sm" name="keterangan" value="<?php echo @$data1['nama_pegawai'] ?>" readonly>
			</div>
			<div class="form-group">
				<label for="">Total Biaya</label>
				<input type="number" class="form-control form-control-sm" name="biaya" autofocus="on" value="">
			</div>
			<br>
			
                  <button type="submit" name="update" class="btn btn-success" style="color: white"><i class="fa fa-check" style="color: white"></i> Selesai</button>
                  <a href="?page=maintenance" class="btn btn-danger">Cancel</a>
           
		</form>
	</div>
 <?php endif ?>
</div>