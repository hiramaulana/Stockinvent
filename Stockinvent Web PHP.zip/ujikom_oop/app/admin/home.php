<div class="container">
<div class="row">
	<div class="col-sm-12">
		<div class="tile text-center">
			<h1 align="center">Inventarisasi Sarana dan Prasarana</h1>
			<hr>
		</div>
	</div>
</div>
</div>
<div class="row">
	
</div>
