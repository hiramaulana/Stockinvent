<?php 

include "../../assets/library/controller.php";

$id = $_GET['id'];

if($id == "1"){

?>

<h1 align="center">Laporan Barang</h1>
<table border="1" align="center" cellpadding="10" cellspacing="0">
	<tr>
		<td>No</td>
		<td>ID Inventaris</td>
		<td>Nama Barang</td>
		<td>Jumlah</td>
		<td>Tanggal Masuk</td>
		
	</tr>
	<?php 
		$sql = mysqli_query($con, "SELECT * FROM tb_inventaris ORDER BY id_inventaris ASC");
		$no = 0;
		while ($data = mysqli_fetch_assoc($sql)){
			$no++
	 ?>
	 <tr>
	 	<td><?php echo $no ?></td>
	 	<td><?php echo $data['id_inventaris'] ?></td>
	 	<td><?php echo $data['nama'] ?></td>
	 	<td><?php echo $data['jumlah'] ?></td>
	 	<td><?php echo $data['tgl_register'] ?></td>
	 </tr>
	 <?php } ?>
</table>
<?php } ?>

<script>
	window.print();
</script>

