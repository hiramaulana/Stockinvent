 <?php 

	@$table = "tb_inventaris";
	@$where = "id_inventaris = '$_GET[id]'";
	@$nama = $_POST['nama'];
	@$form = "?page=barang";
	@$keterangan = $_POST['keterangan'];
	@$jumlah = $_POST['jumlah'];
	@$jenis2 = $_POST['jenis'];
	@$ruang2 = $_POST['ruang'];

 if(isset($_GET['edit'])){	
 	$disabled = 'disabled';
 	$autofocus = 'autofocus="on"';
 	$edit = $perintah->edit($con, $table, $where);
  	foreach ($edit as $edit) {}
  		$ruang = $edit['id_ruang'];
  		$jenis = $edit['id_jenis'];
  	$table1 = "tb_ruang";
  	$where1 = "id_ruang = $ruang";
  	$editruang = $perintah->tampil1($con, $table1, $where1);
  	foreach ($editruang as $editruang) {}
  		$ruang1 = $editruang['nama_ruang'];
  	$table2 = "tb_jenis";
  	$where2 = "id_jenis = $jenis";
  	$editjenis = $perintah->tampil1($con, $table2, $where2);
  	foreach ($editjenis as $editjenis) {}
  		$jenis1 = $editjenis['nama_jenis'];
 }

if(isset($_POST['simpan'])){	
	$length = 2;
	$randomString1 = substr(str_shuffle("HIRAMAULANAPASTIBISABISBCDEFGJKLMNOQUVWXYZ"), 0, $length);
	$kd_invent = $randomString1;
	$alert = "Barang Berhasil diinput Silahkan Hubungi Operator";
	$isi = "id_inventaris = '', nama = '$nama', kondisi = 'Baik', keterangan = '$keterangan', jumlah = '$jumlah', id_jenis = '$jenis2', tgl_register = '$tgl_now', id_ruang = '$ruang2', kd_inventaris = '$kd_invent', id_petugas = '$cookies', status = '1'";
	$perintah->simpan($con, $table, $isi, $alert, $form);
}

if(isset($_POST['update'])){
	$isi = "id_jenis = '$jenis2', id_ruang = '$ruang2', nama = '$nama', keterangan = '$keterangan'";
	$perintah->update($con, $table, $isi, $where, $form);
}

if(isset($_GET['hapus'])){
	$perintah->hapus($con, $table, $where, $form);
}

 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Barang</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Barang</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th>Jumlah</th>
					<th>Ruangan</th>
					<th>Status</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$isi = $perintah->tampilbarang($con);
					foreach ($isi as $data) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data['id_inventaris'] ?></td>
					<td><?php echo $data['nama'] ?></td>
					<td><?php echo $data['keterangan'] ?></td>
					<td><?php echo $data['jumlah'] ?></td>
					<td><?php echo $data['nama_ruang'] ?></td>
					<?php 
						if($data['status'] == 1){
							$status = 'Menunggu Konfirmasi Petugas Gudang';
							$warna = "black";
						}else if($data['status'] == 2){
							$status = 'Barang Sedang dikirimkan Ke Gudang';
							$warna = "purple";
						}else if($data['status'] == 3){
							$status = 'Barang Tersedia di Gudang';
							$warna = "green";
						}else if($data['status'] == 4){
							$status = 'Barang Sedang dipinjam';
							$warna = "blue";
						}else if($data['status'] == 5){
							$status = 'Barang dilaporkan Rusak';
							$warna = "red";
						}else if($data['status'] == 6){
							$status = 'Barang Sedang diperbaiki';
							$warna = "yellow";
						}

					?>
					<td style="color:<?php echo $warna ?>;"><strong><?php echo $status ?></strong></td>
					<td><a href="?page=barang&edit&id=<?php echo $data['id_inventaris'] ?>" class=" btn btn-success"><i class="fa fa-pencil"></i></a> &nbsp; 
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=barang&hapus&id=<?php echo $data['id_inventaris'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Barang</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Ruang</label>
				<select <?php echo @$autofocus ?> name="ruang" class="form-control">
					<option value="<?php echo @$edit['id_ruang'] ?>"><?php echo @$ruang1 ?></option>
					<?php 
						$table = 'tb_ruang';
						$where1 = "status = 'Tersedia'";
						$isi1 = $perintah->tampil1($con, $table, $where1);
						foreach ($isi1 as $data1) { 
					?>
					<option value="<?php echo $data1['id_ruang'] ?>"><?php echo $data1['nama_ruang']?></option>
					<?php 
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="">Jenis</label>
				<select name="jenis" class="form-control">
					<option value="<?php echo @$edit['id_jenis'] ?>"><?php echo @$jenis1 ?></option>
					<?php 
						$table = 'tb_jenis';
						$isi2 = $perintah->tampil($con, $table);
						foreach ($isi2 as $data2) { 
					?>
					<option value="<?php echo $data2['id_jenis'] ?>"><?php echo $data2['nama_jenis']?></option>
					<?php 
						}
					?>
				</select>
			</div>
			<div class="form-group">
				<label for="">Nama</label>
				<input type="text" class="form-control form-control-sm" name="nama" value="<?php echo @$edit['nama'];?>">
			</div>
			<div class="form-group">
				<label for="">Jumlah</label>
				<input type="text" class="form-control form-control-sm" name="jumlah" value="<?php echo @$edit['jumlah'] ?>" <?php echo @$disabled ?>>
			</div>
			<div class="form-group">
				<label for="">Keterangan</label>
				<input type="text" class="form-control form-control-sm" name="keterangan" value="<?php echo @$edit['keterangan'] ?>">
			</div>
			<br>
			<?php if (isset($_GET['edit'])): ?>
                  <button type="submit" name="update" class="btn btn-warning" style="color: white"><i class="fa fa-check" style="color: white"></i> Update</button>
                  <a href="<?php echo $form ?>" class="btn btn-danger">Cancel</a>
            <?php endif ?>
            <?php if (!isset($_GET['edit'])): ?>  
                      <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
             <?php endif ?>
		</form>
	</div>
</div>