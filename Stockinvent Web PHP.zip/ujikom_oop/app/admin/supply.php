<?php 
	
	@$table = "tb_supply";
	@$where = "id_supply = '$_GET[id]'";
	@$id_inventaris = $_POST['barang'];
	@$jumlah = $_POST['jumlah'];
	@$form = "?page=supply";

	if(isset($_POST['simpan'])){
		@$isi = "id_supply = '', id_inventaris = '$id_inventaris', jumlah = '$jumlah', tgl_register = '$tgl_now'";
		@$alert = "Data Supply Berhasil ditambahkan";
		$perintah->simpan($con, $table, $isi, $alert, $form);
	}

	if(isset($_GET['hapus'])){
	$perintah->hapus($con, $table, $where, $form);
}


 ?>
 <div class="col-sm-12">
 	<div class="tile">
		<h3>Data Supply</h3>
		<hr>
		<table class="table table-bordered" id="example">
			<thead>
				<tr>
					<th>No</th>
					<th>ID Supply</th>
					<th>Nama Barang</th>
					<th>Jumlah</th>
					<th>Tanggal Masuk</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					$no = 0;
					$isi = $perintah->tampilsupply($con);
					foreach ($isi as $data) { 
						$no++
				?>
				<tr>
					<td><?php echo $no ?></td>
					<td><?php echo $data['id_supply'] ?></td>
					<td><?php echo $data['nama'] ?></td>
					<td><?php echo $data['jumlah'] ?></td>
					<td><?php echo $data['tgl_register'] ?></td>
					<td>
					<a onclick="return confirm('Yakin Ingin Menghapus ?')" href="?page=supply&hapus&id=<?php echo $data['id_supply'] ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
					</td>
				</tr>
				<?php 
					} 
				?>
			</tbody>
		</table>
 	</div>
 </div>
<div class="col-sm-12">
	<div class="tile">
		<h3>Input Supply</h3>
		<hr>
		<form method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label for="">Barang</label>
				<select name="barang" class="form-control">
					<?php 
						$isi = $perintah->tampilbarang($con);
						foreach ($isi as $data1) { 
					?>
					<option value="<?php echo $data1['id_inventaris'] ?>"><?php echo $data1['nama']?></option>
					<?php 
						}

					?>
				</select>
			</div>
			<div class="form-group">
				<label for="">Jumlah</label>
				<input type="text" class="form-control form-control-sm" name="jumlah" value="">
			</div>
			<br>  
                <button type="submit" name="simpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
		</form>
	</div>
</div>