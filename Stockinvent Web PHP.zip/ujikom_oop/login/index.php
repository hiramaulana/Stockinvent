<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>STOCKINVENT | Login</title>
    <!-- Meta & CSS -->
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <?php
        
        include "../assets/library/controller.php";
        session_start();
        $perintah = new oop();
        @$username = $_POST['username'];
        @$password = $_POST['password'];        
        if (isset($_POST['login'])) {
            $perintah->login($con, $username, $password);
        }

     ?>
    <style>
        body{
            background-image: url("../img/9.JPG");
            
            background-size: cover;
        }
        .form-control::focus{
            background-color: yellow;
        }
        .logo-new{
            margin-top: -80px;
            margin-bottom: -10px;
            font-size: 40px;
        }
    </style>
</head>
<body>

    <section class="login-content" >
      <br>
      <div class="login-box">
        <form class="login-form" method="post" >
        <br>
        <br>
        <div class="form-group">
            <center><p class="logo-new" style="color:black; font-family: calibri; font-style: bold">STOCKINVENT</p></center>
        <br>
        </div>
          <div class="form-group">
            <label class="control-label">Username</label>
            <input class="form-control" type="text" autofocus name="username" autocomplete="off" autofocus="on">
          </div>
          <div class="form-group">
            <label class="control-label">Password</label>
            <input class="form-control" type="password" name="password">
          </div>
          <br>
          <div class="form-group btn-container">
            <button class="btn btn-success btn-block" name="login"><i class="fa fa-sign-in fa-lg fa-fw"></i> MASUK</button>
          </div>
      </div>
    </section>
    <script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/main.js"></script>
    <script src="../js/plugins/pace.min.js"></script>
</body>
</html>