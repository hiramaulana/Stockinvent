-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2019 at 02:02 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ujikom`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_detail_pinjam`
--

CREATE TABLE `tb_detail_pinjam` (
  `id_detail_pinjam` int(11) NOT NULL,
  `id_inventaris` int(11) NOT NULL,
  `id_peminjaman` varchar(25) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `tb_detail_pinjam`
--
DELIMITER $$
CREATE TRIGGER `kembali_barang` AFTER DELETE ON `tb_detail_pinjam` FOR EACH ROW BEGIN
UPDATE tb_inventaris
SET jumlah = jumlah + OLD.jumlah
WHERE 
id_inventaris = OLD.id_inventaris;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `pinjam_barang` AFTER INSERT ON `tb_detail_pinjam` FOR EACH ROW BEGIN
UPDATE tb_inventaris 
SET jumlah= jumlah - NEW.jumlah
WHERE
id_inventaris = NEW.id_inventaris;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tb_inventaris`
--

CREATE TABLE `tb_inventaris` (
  `id_inventaris` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `kondisi` varchar(5) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `tgl_register` datetime NOT NULL,
  `id_ruang` int(11) NOT NULL,
  `kd_inventaris` varchar(10) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_inventaris`
--

INSERT INTO `tb_inventaris` (`id_inventaris`, `nama`, `kondisi`, `keterangan`, `jumlah`, `id_jenis`, `tgl_register`, `id_ruang`, `kd_inventaris`, `id_petugas`, `status`) VALUES
(1, 'Speker Simbadda', 'Baik', 'Speaker Merk Simbadda High Volume', 100, 1, '2019-04-03 00:00:00', 1, 'AF', 1, '3'),
(2, 'Proyektor ESEMKA', 'Baik', 'Proyektor BOS 2018', 75, 1, '2019-04-01 00:00:00', 1, 'RF', 1, '1'),
(3, 'MIC Djabesmen', 'Baik', 'Microphone Portable', 63, 1, '2019-04-04 00:00:00', 1, 'GG', 1, '3'),
(4, 'Terminal Kuningan', 'Baik', 'Terminal 4 Port Panjang 3 Meter', 84, 1, '2019-04-04 00:00:00', 1, 'GS', 1, '3'),
(5, 'Adapter LAN Port USB', 'Baik', 'Adapter Laptop Yang Tidak Memiliki Port Untuk Lan', 30, 1, '2019-04-04 00:00:00', 1, 'LN', 1, '2'),
(6, '1 Koper Tool Kits', 'Baik', ' Koper Yang Berisi Perlatan-Peralatan Kerja', 8, 1, '2019-04-04 00:00:00', 1, 'VG', 1, '3'),
(7, 'Sapu SUPREME', 'Baik', 'Sapu Merk SUPREME Dengan Gagang Berbahan Emas', 1, 2, '2019-04-04 00:00:00', 2, 'LD', 1, '3'),
(8, 'Pengki OFF-White', 'Baik', 'Pengki OFF-White Import Langsung Dari Amerika', 1, 2, '2019-04-04 00:00:00', 2, 'BD', 1, '3'),
(9, 'Gunting Rumput Besar', 'Baik', 'Gunting Untuk Memotong Rumput', 24, 2, '2019-04-04 00:00:00', 2, 'VF', 1, '3');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenis`
--

CREATE TABLE `tb_jenis` (
  `id_jenis` int(11) NOT NULL,
  `nama_jenis` varchar(225) NOT NULL,
  `kd_jenis` varchar(10) NOT NULL,
  `keterangan` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jenis`
--

INSERT INTO `tb_jenis` (`id_jenis`, `nama_jenis`, `kd_jenis`, `keterangan`) VALUES
(1, 'Elektronik', 'AH', 'Jenis Barang Yang Membutuhkan Daya Listrik'),
(2, 'Non-Elektronik', 'AB', 'Jenis Barang Yang Tidak Membutuhkan Daya Listrik');

-- --------------------------------------------------------

--
-- Table structure for table `tb_level`
--

CREATE TABLE `tb_level` (
  `id_level` int(11) NOT NULL,
  `nama_level` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_level`
--

INSERT INTO `tb_level` (`id_level`, `nama_level`) VALUES
(1, 'Administrator'),
(2, 'Operator');

-- --------------------------------------------------------

--
-- Table structure for table `tb_maintenance`
--

CREATE TABLE `tb_maintenance` (
  `id_maintenance` int(11) NOT NULL,
  `id_inventaris` int(11) NOT NULL,
  `ket_rusak` text NOT NULL,
  `jumlah` int(11) NOT NULL,
  `jumlah_rusak` int(11) NOT NULL,
  `id_peminjaman` varchar(10) NOT NULL,
  `status_perb` int(1) NOT NULL,
  `biaya` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_pegawai`
--

CREATE TABLE `tb_pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(225) NOT NULL,
  `nip` varchar(11) NOT NULL,
  `password` varchar(225) NOT NULL,
  `alamat` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`id_pegawai`, `nama_pegawai`, `nip`, `password`, `alamat`) VALUES
(1, 'Abdul Malik', '1234', '080601', 'Jalan Bahagia No. 01 Cibinong Kab Bogor'),
(2, 'Umar Said', ' 1229', '070295', 'Jalan Ketimuran No. 99 Bogor Timur'),
(3, 'Udin Ridwan', '1231', '070394', 'Jalan Kemandirian No. 46 Ciseeng Bogor Barat'),
(4, 'Ucok Steve', '1230', '150499', 'Jalan Keadilan No. 55 Melawai Bogor Selatan'),
(5, 'Komeng Meng', '1226', '251297', 'Jalan Shangrila No. 13 Kab Bogor'),
(6, 'Jajang Ujang', '1227', '210902', 'Jalan Makmur No. 9 Sukasari Bogor'),
(7, 'Asep Jamal', '1228', '150789', 'Jalan Pace No. 1 Cijeruk Kab Bogor');

-- --------------------------------------------------------

--
-- Table structure for table `tb_peminjaman`
--

CREATE TABLE `tb_peminjaman` (
  `id_peminjaman` varchar(25) NOT NULL,
  `id_inventaris` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tgl_pinjam` datetime NOT NULL,
  `tgl_kembali` date NOT NULL,
  `tgl_kembali1` datetime NOT NULL,
  `status_pinjam` varchar(2) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `nama_petugas` varchar(225) NOT NULL,
  `id_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_petugas`
--

INSERT INTO `tb_petugas` (`id_petugas`, `username`, `password`, `nama_petugas`, `id_level`) VALUES
(1, 'root', 'root', 'Hira Maulana', 1),
(2, 'opr', 'root', 'Maulana Hira', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tb_ruang`
--

CREATE TABLE `tb_ruang` (
  `id_ruang` int(11) NOT NULL,
  `nama_ruang` varchar(225) NOT NULL,
  `kd_ruang` varchar(10) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_ruang`
--

INSERT INTO `tb_ruang` (`id_ruang`, `nama_ruang`, `kd_ruang`, `keterangan`, `status`) VALUES
(1, 'Gudang 1', ' JK', 'Gudang Dengan Lahan 50 Hektar Terletak di Samping Masjid Utara', 'Tersedia'),
(2, 'Gudang 2', 'KD', 'Gudang Dengan Lahan 10 Hektar Terletak di Sebelah Selatan Dekat Lahan Parkir Mobil', 'Tersedia'),
(3, 'Gudang 3', 'ND', 'Gudang Dengan Lahan 5 Hektar Terletak di Tengah Perkantoran', 'Tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `tb_supply`
--

CREATE TABLE `tb_supply` (
  `id_supply` int(11) NOT NULL,
  `id_inventaris` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tgl_register` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `tb_supply`
--
DELIMITER $$
CREATE TRIGGER `batal_barang` AFTER DELETE ON `tb_supply` FOR EACH ROW BEGIN
UPDATE tb_inventaris
SET jumlah = jumlah - OLD.jumlah
WHERE 
id_inventaris = OLD.id_inventaris;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tambah_barang` AFTER INSERT ON `tb_supply` FOR EACH ROW BEGIN
UPDATE tb_inventaris 
SET jumlah= jumlah + NEW.jumlah
WHERE
id_inventaris = NEW.id_inventaris;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_detail_pinjam`
--
ALTER TABLE `tb_detail_pinjam`
  ADD PRIMARY KEY (`id_detail_pinjam`),
  ADD UNIQUE KEY `id_peminjaman` (`id_peminjaman`);

--
-- Indexes for table `tb_inventaris`
--
ALTER TABLE `tb_inventaris`
  ADD PRIMARY KEY (`id_inventaris`);

--
-- Indexes for table `tb_jenis`
--
ALTER TABLE `tb_jenis`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `tb_level`
--
ALTER TABLE `tb_level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `tb_maintenance`
--
ALTER TABLE `tb_maintenance`
  ADD PRIMARY KEY (`id_maintenance`);

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `tb_peminjaman`
--
ALTER TABLE `tb_peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`);

--
-- Indexes for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`id_petugas`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tb_ruang`
--
ALTER TABLE `tb_ruang`
  ADD PRIMARY KEY (`id_ruang`);

--
-- Indexes for table `tb_supply`
--
ALTER TABLE `tb_supply`
  ADD PRIMARY KEY (`id_supply`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_detail_pinjam`
--
ALTER TABLE `tb_detail_pinjam`
  MODIFY `id_detail_pinjam` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_inventaris`
--
ALTER TABLE `tb_inventaris`
  MODIFY `id_inventaris` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tb_jenis`
--
ALTER TABLE `tb_jenis`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_level`
--
ALTER TABLE `tb_level`
  MODIFY `id_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_maintenance`
--
ALTER TABLE `tb_maintenance`
  MODIFY `id_maintenance` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_petugas`
--
ALTER TABLE `tb_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_ruang`
--
ALTER TABLE `tb_ruang`
  MODIFY `id_ruang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_supply`
--
ALTER TABLE `tb_supply`
  MODIFY `id_supply` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
